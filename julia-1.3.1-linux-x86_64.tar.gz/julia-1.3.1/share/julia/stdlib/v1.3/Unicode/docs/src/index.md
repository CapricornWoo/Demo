# Unicode

```@docs
Unicode.isassigned
Unicode.normalize
Unicode.graphemes
```
